# Exam#2

Bouncing ball for the final project of Computer Organization

# How to play

Run the folder ParcialFinal on the VMemulator from Nand2Tetris Suit.

#Controls

![Controles](https://user-images.githubusercontent.com/53051438/140428415-15b9b0a0-b86e-4a43-8f45-57e7b1db1b3c.png)
